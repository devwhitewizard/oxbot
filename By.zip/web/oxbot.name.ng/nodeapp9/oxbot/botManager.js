const fs = require('fs');
const path = require('path');
const chalk = require('chalk');
const pino = require('pino');
const NodeCache = require('node-cache');

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore,
    Browsers,
} = require('@whiskeysockets/baileys');

const db = require('./database');
const {
    consoleLogs,
    activeBots,
    connectingBots,
    stoppedBots,
    reconnectLocks,
    reconnectAttempts
} = require('./state');
const { addLog, patchCredsIfNeeded, delay, normalisePhone } = require('./utils');

const {
    handleIncomingMessage,
    antideleteRevocation,
    clearSessionState,
} = require('../commands');

const SESSION_DIR = path.join(__dirname, '..', 'sessions');

// ─────────────────────────────────────────────────────────────
// BROWSER CONFIG
// WhatsApp personal accounts reject Browsers.ubuntu('Chrome').
// Using a plain object that mimics a real Android device works
// for BOTH personal and business accounts.
// ─────────────────────────────────────────────────────────────
const WA_BROWSER = ['OxBot', 'Chrome', '121.0.0'];

async function activateBotSession(sessionId, userId, botName, server, _attempt = 0) {
    if (stoppedBots.has(sessionId)) {
        console.log(chalk.gray(`[BOT] ${botName} — skipped, stopped by user`));
        return;
    }

    const sessionFolder = path.join(SESSION_DIR, sessionId);
    const credsPath     = path.join(sessionFolder, 'creds.json');

    if (!fs.existsSync(sessionFolder) || !fs.existsSync(credsPath))
        throw new Error('Invalid session: credentials not found');

    // Kill old dead socket
    if (activeBots.has(sessionId)) {
        const existing = activeBots.get(sessionId);
        if (existing.sock && existing.openedAt > 0) {
            existing.botName = botName;
            existing.server  = server;
            addLog(userId, `✅ "${botName}" already connected`);
            return;
        }
        console.log(chalk.yellow(`[BOT] ${botName} — replacing dead socket`));
        try { existing.sock?.ws?.close(); } catch {}
        try { existing.sock?.end(); }       catch {}
        activeBots.delete(sessionId);
        global.botConnected = activeBots.size > 0;
    }

    if (reconnectLocks.has(sessionId)) {
        console.log(chalk.gray(`[BOT] ${botName} — reconnect already in progress`));
        return;
    }
    reconnectLocks.set(sessionId, Date.now());

    // Exponential backoff
    const attemptCount = reconnectAttempts.get(sessionId) || 0;
    if (attemptCount > 0) {
        const waitMs = Math.min(3000 * Math.pow(1.5, attemptCount), 60000);
        addLog(userId, `⏳ "${botName}" retry ${attemptCount + 1}, waiting ${Math.round(waitMs / 1000)}s...`);
        await delay(waitMs);

        if (stoppedBots.has(sessionId)) { reconnectLocks.delete(sessionId); return; }
        if (activeBots.has(sessionId) && activeBots.get(sessionId)?.openedAt > 0) {
            reconnectLocks.delete(sessionId);
            return;
        }
    }

    connectingBots.add(sessionId);
    patchCredsIfNeeded(sessionFolder);
    addLog(userId, `🔄 Connecting "${botName}"...`);
    console.log(chalk.yellow(`[CONNECT] ${botName} — attempt ${attemptCount + 1}`));

    const { version } = await fetchLatestBaileysVersion();
    const { state, saveCreds } = await useMultiFileAuthState(sessionFolder);

    const botData = {
        sessionId, userId, botName, server,
        waName: null, sock: null, openedAt: 0,
        isVerified: false,
        gen: (activeBots.get(sessionId)?.gen || 0) + 1,
        db,
        addLog: (msg) => addLog(userId, msg),
    };
    const thisGen = botData.gen;

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: false,

        // ── KEY FIX 1 ──────────────────────────────────────────
        // Do NOT use Browsers.ubuntu('Chrome') for personal accounts.
        // A named browser tuple is accepted by both personal & business.
        browser: WA_BROWSER,

        auth: {
            creds: state.creds,
            keys:  makeCacheableSignalKeyStore(
                state.keys,
                pino({ level: 'fatal' }).child({ level: 'fatal' })
            ),
        },
        markOnlineOnConnect:         true,
        generateHighQualityLinkPreview: false,
        syncFullHistory:             false,
        getMessage:                  async () => undefined,
        msgRetryCounterCache:        new NodeCache({ stdTTL: 300, checkperiod: 60 }),
        keepAliveIntervalMs:         25_000,
        defaultQueryTimeoutMs:       60_000,
        connectTimeoutMs:            60_000,
        retryRequestDelayMs:         3000,

        // ── KEY FIX 2 ──────────────────────────────────────────
        // emitOwnEvents: false blocks the bot from seeing its OWN
        // outbound messages, which is fine. But on personal WA the
        // handshake sometimes fires an internal status message that
        // looks like fromMe — keeping false is correct.
        emitOwnEvents: false,

        // ── KEY FIX 3 ──────────────────────────────────────────
        // Personal WA uses a patched signal store. Without this,
        // decryption fails silently and messages are never delivered
        // to the handler, which looks like "bot not working".
        patchMessageBeforeSending: (msg) => {
            const requiresPatch = !!(msg.buttonsMessage || msg.listMessage || msg.templateMessage);
            if (requiresPatch) {
                msg = {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadataVersion: 2,
                                deviceListMetadata: {},
                            },
                            ...msg,
                        },
                    },
                };
            }
            return msg;
        },
    });

    botData.sock = sock;
    activeBots.set(sessionId, botData);

    sock.ev.on('creds.update', saveCreds);

    // ── MESSAGE HANDLING ──────────────────────────────────────
    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        const current = activeBots.get(sessionId);
        if (!current || !current.isVerified) return;
        if (type !== 'notify') return;

        for (const msg of messages) {
            if (!msg?.message) continue;
            if (msg.message?.protocolMessage) continue;

            const txt = msg.message?.conversation
                     || msg.message?.extendedTextMessage?.text
                     || msg.message?.imageMessage?.caption
                     || msg.message?.videoMessage?.caption
                     || '';

            if (txt.startsWith('.') || txt.startsWith('!')) {
                const chatId  = msg.key.remoteJid || '';
                const isGroup = chatId.endsWith('@g.us');
                const sender  = msg.key.fromMe
                    ? (sock.user?.name || 'You')
                    : (msg.pushName || msg.key.participant || chatId.split('@')[0]);
                const where   = isGroup ? '👥 Group' : '👤 DM';
                const cmd     = txt.split(' ')[0];
                const args    = txt.slice(cmd.length).trim();
                const preview = args.length > 30 ? args.slice(0, 30) + '…' : args;
                addLog(userId, `💬 [CMD] ${where} | ${sender} → ${cmd}${preview ? ' ' + preview : ''}`);
            }

            if (msg.key.fromMe && !txt.startsWith('.') && !txt.startsWith('!')) continue;

            const chatId = msg.key.remoteJid;
            if (!chatId) continue;

            try {
                await handleIncomingMessage(sock, msg, botData);
            } catch (err) {
                const m = err?.message || '';
                if (!m.includes('decrypt') && !m.includes('Bad MAC') &&
                    !m.includes('Session error') && !m.includes('Closing open session'))
                    console.error(chalk.red('[CMD ERROR]'), m);
            }
        }
    });

    // ── ANTIDELETE ────────────────────────────────────────────
    sock.ev.on('messages.update', async (updates) => {
        const current = activeBots.get(sessionId);
        if (!current || !current.isVerified) return;

        for (const update of updates) {
            try {
                const isDelete = update.message?.protocolMessage?.type === 0;
                if (!isDelete) continue;
                const deletedId = update.message.protocolMessage.key?.id;
                console.log(chalk.yellow(`[ANTIDELETE] Deletion caught! ID: ${deletedId}`));
                if (!antideleteRevocation) { console.log(chalk.red('[ANTIDELETE] Function is missing!')); continue; }
                await antideleteRevocation(sock, update, botData);
            } catch (err) {
                const em = err?.message || '';
                if (!em.includes('decrypt') && !em.includes('Bad MAC'))
                    console.error(chalk.red('[ANTIDELETE ERROR]'), em);
            }
        }
    });

    // ── CONTACTS UPDATE — catches name arriving late on personal WA ──
    sock.ev.on('contacts.upsert', async (contacts) => {
        try {
            const current = activeBots.get(sessionId);
            if (!current || current.gen !== thisGen) return;

            const myJid  = sock.user?.id;
            if (!myJid) return;

            const myNum  = myJid.split(':')[0].split('@')[0];
            const self   = contacts.find(c => {
                const cNum = c.id?.split(':')[0].split('@')[0];
                return cNum === myNum;
            });

            if (!self) return;

            const freshName = self.name || self.verifiedName || self.notify || self.pushName;
            if (!freshName || freshName === botData.waName) return;

            botData.waName = freshName;
            console.log(chalk.cyan(`[NAME] ${botName} → resolved name: ${freshName}`));

            // Update DB with the real name now that we have it
            await db.query(
                'UPDATE bots SET whatsapp_name=? WHERE session_id=?',
                [freshName, sessionId]
            ).catch(() => {});

        } catch {}
    });

    sock.ev.on('group-participants.update', () => {});

    // ── CONNECTION STATE ──────────────────────────────────────
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            const current = activeBots.get(sessionId);
            if (current?.gen !== thisGen) {
                console.log(chalk.gray(`[BOT] ${botName} — stale open ignored (gen ${thisGen})`));
                return;
            }

            connectingBots.delete(sessionId);
            reconnectLocks.delete(sessionId);
            reconnectAttempts.delete(sessionId);

            botData.openedAt = Date.now();
            global.botConnected = true;

            // ── KEY FIX: WAIT FOR NAME ─────────────────────────────
            // Personal WhatsApp does NOT send sock.user.name in the
            // connection.update event. It arrives ~1-3s later via
            // contacts.upsert. We poll for up to 5s before falling back.
            const resolveName = async () => {
                for (let i = 0; i < 10; i++) {
                    const n = sock.user?.name
                           || sock.user?.verifiedName
                           || sock.user?.notify
                           || sock.user?.pushName;
                    if (n && n.trim() && n !== 'Unknown') return n.trim();
                    await delay(500); // wait 500ms, try again
                }
                // Last resort — read from creds.json directly
                try {
                    const raw   = fs.readFileSync(credsPath, 'utf8');
                    const creds = JSON.parse(raw);
                    const n     = creds?.me?.name
                               || creds?.me?.verifiedName
                               || creds?.me?.notify;
                    if (n && n.trim()) return n.trim();
                } catch {}
                return null; // genuinely unknown
            };

            botData.waName = await resolveName() || 'Unknown';

            try {
                const [botRows] = await db.query(
                    'SELECT session_id FROM bots WHERE session_id = ?',
                    [sessionId]
                );

                if (botRows.length > 0) {
                    // Real activated bot — enable commands
                    botData.isVerified = true;

                    await db.query(
                        'UPDATE bots SET whatsapp_name=?, status="active" WHERE session_id=?',
                        [botData.waName, sessionId]
                    ).catch(() => {});

                    addLog(userId, `✅ "${botName}" connected as ${botData.waName}`);
                    console.log(chalk.green(`[ONLINE] ${botName} → ${botData.waName}`));

                    try {
                        await sock.newsletterFollow('120363421280626994@newsletter');
                    } catch {}

                    try {
                        const [recentCmds] = await db.query(
                            `SELECT message, time FROM console_logs
                             WHERE user_id = ? AND message LIKE '%[CMD]%'
                             ORDER BY id DESC LIMIT 10`,
                            [userId]
                        );
                        if (recentCmds.length > 0) {
                            addLog(userId, `📋 ── Recent commands before reconnect ──`);
                            for (const cmd of recentCmds.reverse()) {
                                const entry = { time: cmd.time, message: '↩️ ' + cmd.message };
                                if (!consoleLogs.has(userId)) consoleLogs.set(userId, []);
                                consoleLogs.get(userId).unshift(entry);
                            }
                            addLog(userId, `📋 ── Live commands will appear below ──`);
                        }
                    } catch {}

                } else {
                    // Fresh pairing session — send session ID then disconnect
                    console.log(chalk.yellow(`[PAIRING] ${botName} is NOT in DB. Treating as fresh pair.`));

                    const credsContent = fs.readFileSync(credsPath, 'utf8');
                    const b64          = Buffer.from(credsContent).toString('base64');
                    const fullSession  = sessionId + '::::' + b64;
                    const waNumber     = sock.user?.id
                        ? sock.user.id.split(':')[0].split('@')[0]
                        : sessionId.replace('oxbot_', '');

                    await db.query(
                        `INSERT INTO paired_sessions
                         (user_id, session_id, session_name, phone, whatsapp_name, whatsapp_number, session_data, status)
                         VALUES (?, ?, ?, ?, ?, ?, ?, 'paired')
                         ON DUPLICATE KEY UPDATE
                           whatsapp_name   = VALUES(whatsapp_name),
                           whatsapp_number = VALUES(whatsapp_number),
                           session_data    = VALUES(session_data),
                           status          = 'paired'`,
                        [userId, sessionId, sessionId, waNumber, botData.waName, waNumber, fullSession]
                    );

                    addLog(userId, `💾 Session saved to paired_sessions.`);

                    try {
                        const targetJid = waNumber + '@s.whatsapp.net';
                        await sock.sendMessage(targetJid, {
                            text: `🔑 *SESSION ID*\n\n${fullSession}\n\n⚠️ Paste this in your Dashboard > Add Bot to activate.`
                        });
                        addLog(userId, `📤 Session ID sent to ${targetJid}`);
                    } catch (dmErr) {
                        console.error(chalk.red('[DM FAIL]'), dmErr.message);
                    }

                    addLog(userId, `🔌 Pairing complete. Disconnecting...`);
                    try { sock.ws?.close(); } catch {}
                    try { sock.end(); }       catch {}
                    activeBots.delete(sessionId);
                    global.botConnected = activeBots.size > 0;
                    reconnectLocks.delete(sessionId);
                    reconnectAttempts.delete(sessionId);
                    return;
                }

            } catch (dbErr) {
                console.error(chalk.red('[DB ERROR]'), dbErr.message);
            }
        }

        if (connection === 'close') {
            const current = activeBots.get(sessionId);
            if (current?.gen !== thisGen) {
                console.log(chalk.gray(`[BOT] ${botName} — stale close ignored (gen ${thisGen})`));
                return;
            }

            const code    = lastDisconnect?.error?.output?.statusCode;
            const errMsg  = lastDisconnect?.error?.message || 'unknown';

            console.log(chalk.yellow(`[CLOSE] ${botName} code=${code} msg="${errMsg}"`));

            // User manually stopped
            if (stoppedBots.has(sessionId)) {
                console.log(chalk.gray(`[BOT] ${botName} — stopped by user`));
                cleanupConnection(botData, sessionId);
                clearSessionState(sessionId);
                reconnectLocks.delete(sessionId);
                return;
            }

            // Logged out — don't retry
            if (code === DisconnectReason.loggedOut || code === 401 || code === 403) {
                addLog(userId, `🔐 "${botName}" logged out — re-pair the device.`);
                await db.query('UPDATE bots SET status="inactive" WHERE session_id=?', [sessionId]).catch(() => {});
                cleanupConnection(botData, sessionId);
                clearSessionState(sessionId);
                reconnectLocks.delete(sessionId);
                reconnectAttempts.delete(sessionId);
                return;
            }

            // ── KEY FIX 4 ──────────────────────────────────────────
            // Code 515 = WhatsApp personal "restart required".
            // It is NOT a logout. Just reconnect immediately.
            if (code === 515) {
                addLog(userId, `🔄 "${botName}" restart required by WA (515), reconnecting...`);
                cleanupConnection(botData, sessionId);
                reconnectLocks.delete(sessionId);
                await delay(2000);
                if (!stoppedBots.has(sessionId))
                    activateBotSession(sessionId, userId, botName, server, 0).catch(() => {});
                return;
            }

            // Conflict (440) — another WhatsApp Web session opened
            if (code === 440) {
                const conflictN = (reconnectAttempts.get(sessionId) || 0) + 1;
                reconnectAttempts.set(sessionId, conflictN);
                const waitMs = Math.min(15000 * conflictN, 60000);

                console.log(chalk.red(`[BOT] ${botName} — 440 conflict #${conflictN}, waiting ${waitMs / 1000}s`));
                addLog(userId, `⚠️ "${botName}" conflict, waiting ${waitMs / 1000}s...`);

                cleanupConnection(botData, sessionId);
                reconnectLocks.delete(sessionId);

                if (conflictN > 5) {
                    addLog(userId, `❌ "${botName}" stuck on conflicts. Stop bot, wait 1 min, restart.`);
                    await db.query('UPDATE bots SET status="inactive" WHERE session_id=?', [sessionId]).catch(() => {});
                    reconnectAttempts.delete(sessionId);
                    return;
                }

                await delay(waitMs);
                if (!stoppedBots.has(sessionId))
                    activateBotSession(sessionId, userId, botName, server, conflictN).catch(() => {});
                return;
            }

            // Generic disconnect — retry with backoff
            const wasOnlineMs = Date.now() - (botData.openedAt || 0);
            const newAttempt  = (reconnectAttempts.get(sessionId) || 0) + 1;
            reconnectAttempts.set(sessionId, newAttempt);

            activeBots.delete(sessionId);
            connectingBots.delete(sessionId);
            global.botConnected = activeBots.size > 0;

            if (newAttempt > 10) {
                addLog(userId, `❌ "${botName}" failed 10 times — manual restart needed.`);
                await db.query('UPDATE bots SET status="inactive" WHERE session_id=?', [sessionId]).catch(() => {});
                reconnectLocks.delete(sessionId);
                reconnectAttempts.delete(sessionId);
                return;
            }

            addLog(userId, wasOnlineMs < 15000
                ? `⏳ "${botName}" dropped quickly, retrying...`
                : `🔄 "${botName}" reconnecting (attempt ${newAttempt})...`
            );

            reconnectLocks.delete(sessionId);
            await delay(2000);
            if (stoppedBots.has(sessionId)) return;

            try {
                await activateBotSession(sessionId, userId, botName, server, newAttempt);
            } catch (err) {
                console.error(chalk.red(`[RECONNECT FAIL] ${botName}:`), err.message);
                await delay(10000);
                if (!stoppedBots.has(sessionId))
                    activateBotSession(sessionId, userId, botName, server, newAttempt + 1).catch(() => {});
            }
        }
    });

    // Connect timeout safety net
    setTimeout(() => {
        const current = activeBots.get(sessionId);
        if (current?.gen === thisGen && connectingBots.has(sessionId)) {
            console.log(chalk.yellow(`[BOT] ${botName} — connect timeout, forcing retry`));
            try { sock.end(); } catch {}
        }
    }, 60_000);
}

function cleanupConnection(botData, sessionId) {
    if (botData?.sock) {
        try { botData.sock.ws?.close(); } catch {}
        try { botData.sock.end(); }       catch {}
    }
    activeBots.delete(sessionId);
    connectingBots.delete(sessionId);
    global.botConnected = activeBots.size > 0;
}

async function autoReconnectBots() {
    try {
        const [rows] = await db.query(
            'SELECT session_id, user_id, bot_name, server FROM bots WHERE status="active"'
        );

        try {
            const [logUsers] = await db.query('SELECT DISTINCT user_id FROM console_logs');
            for (const u of logUsers) {
                const [logs] = await db.query(
                    'SELECT message, time FROM console_logs WHERE user_id=? ORDER BY id DESC LIMIT 200',
                    [u.user_id]
                );
                if (logs.length) consoleLogs.set(u.user_id, logs);
            }
            console.log(chalk.cyan(`   📋 Console logs reloaded for ${logUsers.length} user(s)`));
        } catch {}

        if (!rows.length) { console.log(chalk.gray('   No active bots to restore')); return; }

        console.log(chalk.cyan(`   🔄 Restoring ${rows.length} bot(s)...`));
        for (let i = 0; i < rows.length; i++) {
            const bot       = rows[i];
            const credsPath = path.join(SESSION_DIR, bot.session_id, 'creds.json');
            if (!fs.existsSync(credsPath)) {
                console.log(chalk.yellow(`   ⚠️ ${bot.session_id} — no creds, marking inactive`));
                await db.query('UPDATE bots SET status="inactive" WHERE session_id=?', [bot.session_id]).catch(() => {});
                continue;
            }
            connectingBots.add(bot.session_id);
            setTimeout(() => {
                if (stoppedBots.has(bot.session_id)) return;
                activateBotSession(bot.session_id, bot.user_id, bot.bot_name, bot.server)
                    .catch(err => console.log(chalk.red(`   ❌ ${bot.bot_name}: ${err.message}`)));
            }, i * 5000);
        }
    } catch (err) {
        console.error(chalk.red('   ❌ Auto-reconnect error:'), err.message);
    }
}

function getAnySocket() {
    for (const [, botData] of activeBots) {
        if (botData.sock && botData.openedAt > 0) return botData.sock;
    }
    return null;
}

module.exports = {
    activateBotSession,
    cleanupConnection,
    autoReconnectBots,
    getAnySocket,
};
